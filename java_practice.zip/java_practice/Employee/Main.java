package Employee;
import java.util.*;
public class Main{
public static void main(String args[])
{
    Scanner s= new Scanner(System.in);
    System.out.println("Enter details");
    System.out.println("Enter department ID");
	int did=s.nextInt();
    System.out.println("Enter department Name");
	String dname=s.next();
    System.out.println("Enter organization Name");
	String oname=s.next();
    System.out.println("Enter level ID");
	int lid=s.nextInt();
    System.out.println("Enter DH-Name");
	String dhname=s.next();
    System.out.print("Do you want to display details, Enter 1 for yes and 0 for No");
    
	Department d1=new Department(did,dname,oname,lid,dhname);
    d1.display();
   
	s.close();
}}