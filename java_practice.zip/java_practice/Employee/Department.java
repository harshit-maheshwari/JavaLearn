package Employee;
public class Department
{
	private int depId;
	private String depName;
	private String OrgName;
	private int locationId;
	private String depHeadName;
	public Department(int depId,String depName, String OrgName, int locationId, String depHeadName)
	{
		System.out.println("\nThese are the details entered by you");
		this.depId=depId;
		this.depName=depName;
		this.OrgName=OrgName;
		this.locationId=locationId;
		this.depHeadName=depHeadName;
	}
	public int getDepId()
	{
		return depId;
	}
	public void setDepId(int depId)
	{
		this.depId=depId;
	}
	public String getDepName()
	{
		return depName;
	}
	public void setDepName(String depName)
	{
		this.depName=depName;
	}
	public String getOrgName()
	{
		return OrgName;
	}
	public void setOrgName(String OrgName)
	{
		this.OrgName=OrgName;
	}
	public int getLocationId()
	{
		return locationId;
	}
	public void setLocationId(int locationId)
	{
		this.locationId=locationId;
	}
	public String getDepHeadName()
	{
		return depHeadName;
	}
	public void setDepHeadName(String depHeadName)
	{
		this.depHeadName=depHeadName;
	}
	public Department()
	{
		System.out.println("This is the default constructor");
	}
	public void display()
	{
		System.out.println("Department Id: "+getDepId());
		System.out.println("Department Name: "+getDepName());
		System.out.println("Organization Name: "+getOrgName());
		System.out.println("Location Id: "+getLocationId());
		System.out.println("Department Head Name: "+getDepHeadName());
    }}
