package InteritenceLearn;
class Parent{
    
    public Parent(){
        System.out.println("Parent");
    }
    public Parent(int a){
        System.out.println("Parent"+a);
    }
}

class Child extends Parent{
    public Child(){
        System.out.println("Child");
    }
    public Child(int x){
        System.out.println("Child"+x);

    }
    

    public Child(int x,int a){
        super(a);
        System.out.println("Child"+x);

    }
}
public class Constusstorinherit {
    public static void main(String[] args) {
        // Parent p=new Child(); 
        
        Child c= new Child(1,2);
    }
}
