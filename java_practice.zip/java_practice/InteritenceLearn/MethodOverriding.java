package InteritenceLearn;


class Super{
    public void display(){
        System.out.println("Hello SUPER");
    }
}
class Sub extends Super{
    // @Override
    public void display(){
        System.out.println("Hello SUB");
    }
}
public class MethodOverriding {
    public static void main(String[] args) {
        Super sup= new Super();
        sup.display();

        Sub sub= new Sub();
        sub.display();
        
        Super ss= new Sub();
        ss.display();
    }
}
