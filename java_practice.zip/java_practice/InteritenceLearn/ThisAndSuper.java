package InteritenceLearn;


class Rectangle{
    int length;
    int breadth;
    int x=10;
    Rectangle(int length, int breadth){
        this.length= length;
        this.breadth= breadth;
        System.out.println("Inside Rectangle...");

    }
    void display(){
        System.out.println("Length: "+this.length+"\nBreadth: "+this.breadth);
    }
}
class Cuboid extends Rectangle{
    int height;
    int x= 20;
    public Cuboid(int length, int height, int breadth){
        super(length,breadth);
        System.out.println("Inside Cuboid...");
        this.height=height;
        System.out.println(x);
        System.out.println(super.x);
    }
}

public class ThisAndSuper {
    public static void main(String[] args) {
        Cuboid c= new Cuboid(1, 30, 03);
    }
    
}
