package InteritenceLearn;
class Account{
    private long accountNumber;
    private String name;
    private String address;
    private String phoneNo;
    private String DOB;
    //constructor
    public Account(long accountNumber,String name,String address,String phoneNo,String DOB){
        this.accountNumber= accountNumber;
        this.name=name;
        this.address=address;
        this.phoneNo=phoneNo;
        this.DOB=DOB;
    }
    
    public Account(long accountNumber,String name,String DOB,String phoneNo){
        this(accountNumber,name,"NAN",phoneNo,DOB);}
    public Account(String name,String phoneNo,String address,long accountNumber){
        this(accountNumber,name,address,phoneNo,"NAN");
    }
    public Account(long accountNumber,String name,String phoneNo){
        this(accountNumber,name,"NAN",phoneNo);
    }
    //getters
    public long getAccountNumber() {
        return accountNumber;
    }
    public String getName() {
        return name;
    }
    public String getAddress() {
        return address;
    }
    public String getPhoneNo() {
        return phoneNo;
    }
    public String getDOB() {
        return DOB;
    }
    //setters
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }
    public void setDOB(String dOB) {
        DOB = dOB;
    }
    public void setAddress(String address) {
        this.address = address;
    }

}

class SavingsAccount extends Account{

    public SavingsAccount(long accountNumber, String name, String phoneNo) {
        super(accountNumber, name, phoneNo);
        //TODO Auto-generated constructor stub
    }

    

    
}

public class Inheritencepractice2 {
    public static void main(String[] args) {
        long accountNumber;String name;String address;String phoneNo;String DOB;
    }
}
