package InteritenceLearn;

class TV{
    public void switchON(){
        System.out.println("Switched ON");
    }
    public void changeChannel(){
        System.out.println("Channel changed");
    }
}
class SmartTV extends TV{
    @Override
    public void switchON(){
        System.out.println("Smart On");
    }
    @Override
    public void changeChannel(){
        System.out.println("Smart Channel Change");
    }
    public void browse(){
        System.out.println("Smart Browsing");
    }
}
public class MethodOverridingExmp1 {
    public static void main(String[] args) {
        TV t= new TV();
        t.switchON();
        t.changeChannel();
        SmartTV s= new SmartTV();
        s.browse();
        s.changeChannel();
        s.switchON();
        TV st= new SmartTV();
        st.switchON();
        //is allowed 
        //st.browse(); is not allowed
        //Smart a= new TV(); is not allowed
    }
}
