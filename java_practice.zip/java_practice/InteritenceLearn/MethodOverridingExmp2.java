package InteritenceLearn;
class Car{
public void start(){
    System.out.println("Start");
}
public void accelerate(){
    System.out.println("Accelerate");
}
public void chargeGear(){
    System.out.println("Grear changed");
}
}
class LuxaryCar extends Car{
     
    public void chargeGear(){
        System.out.println("Automatic Gear Luxury");
    }  
    public void openRoof(){
        System.out.println("Open Roof Luxury");
    }
}
public class MethodOverridingExmp2 {
    public static void main(String[] args) {
        Car c= new LuxaryCar();
        c.start();
        c.accelerate();
        c.chargeGear();
        //c.openRoof();
    }
    
}
