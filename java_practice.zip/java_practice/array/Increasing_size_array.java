package array;
public class Increasing_size_array {
    public static void main(String[] args) {
        int A[]={1,23,4,3,2,45,6654,432,23};
        int B[]=new int[A.length*2];
        for(int i=0;i<A.length;i++){
            B[i]=A[i];
        }
        for(int i=0;i<B.length;i++){
            System.out.print(B[i]+" ");
        }
    }
}
