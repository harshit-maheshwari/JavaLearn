package array;
public class Array_rotation {
    public static void main(String[] args) {
        int A[]={1,4,3,34,234,21,13,4,5,67,8,88,8,96,5678};
        int temp=A[0];
        for(int i=1;i<A.length;i++){
            A[i-1]=A[i];
        }
        A[A.length-1]=temp;
        for (int i : A) {
            System.out.print(i+" ");
        }
    }
}
