package array;
public class inserting_array {
public static void main(String[] args) {
    int n=10;
    int A[]=new int[n];
    A[0]=5;
    A[1]=54;
    A[2]=4;
    A[3]=342;
    int x=234;
    int index= 2;
    for(int i=n-1 ;i>index;i--){
        A[i]=A[i-1];
    }
    A[index]=x;
    for(int i=0;i<n;i++){
        System.out.print(A[i]+" ");
    }


}
}
