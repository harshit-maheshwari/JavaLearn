package array;
public class deleting_array {
    public static void main(String[] args) {
        int x=4;
        int n=10;
        int A[]= new int[n];
        A[0]=21; A[1]=232; A[2]=123; A[3]=231;
        A[4]=543; A[5]=765; A[6]=654;
        for(int i=x;i<n-1;i++){
            A[i]=A[i+1];
        }
        for(int i=0;i<n;i++){
            System.out.print(A[i]+" ");
        }
    }
}
