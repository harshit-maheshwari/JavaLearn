package array;
// import java.util.Scanner;

class second_max
{
    public static void main(String[] args) 
    {
        int A[]= {1,3,4,2,3,2,334,5654,23,2345,3,89};
        int max= Integer.MIN_VALUE;
        int max2= Integer.MIN_VALUE;
        for(int i=0;i<A.length;i++){
            if(A[i]>max){
                max2=max;
                max=A[i];
            }
            else if(A[i]>max2){
                max2=A[i];
            }
        }
        System.out.println(max2);
    }
}
