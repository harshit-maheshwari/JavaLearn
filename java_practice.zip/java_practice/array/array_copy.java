package array;
public class array_copy {
    public static void main(String[] args) {
        int A[]={1,23,4,3,2,45,6654,432,23};
        int B[]= new int[A.length];
        int Reverse_copy[]= new int[A.length];
        for(int i=0;i<A.length;i++){
            B[i]=A[i];
            Reverse_copy[A.length-i-1]=A[i];

        }
        for(int i=0;i<A.length;i++){
            System.out.print(B[i]+" ");
          
        }
        System.out.println("");
        for(int i=0;i<A.length;i++){
            
            System.out.print(Reverse_copy[i]+" ");
        }
    }
}
