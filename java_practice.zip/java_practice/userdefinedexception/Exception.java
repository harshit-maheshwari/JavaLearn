package userdefinedexception;
import java.util.Scanner;

 

class InvalidException  extends Exception  
{  
    public InvalidException ()  
    {  
        // calling the constructor of parent Exception   
    }  
}  
 

public class Exception {

 

    public static void main(String[] args)
    {
        int salary=0;
        int bonus=0;
        int tot=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter salary and bonus");
        salary=sc.nextInt();
        bonus=sc.nextInt();
        tot=salary+bonus; //sensitive code
        try
        {
        if(tot>50000) //checked 
        {
            throw new InvalidException(); //forcefully, raising exception
        }
        }
        catch(InvalidException e)
        {
            System.out.println(e);
            e.printStackTrace();
        }
        System.out.println("Total Salary: "+tot);
        System.out.println("End of program: ");

    }

 

}