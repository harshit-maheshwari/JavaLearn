package objector;
class Student{
public int rollnumber;
public String name;
public int sub1, sub2, sub3;
public double percentage(){
    return total()/3;
}
public double total(){
   return sub1+sub2+ sub3;
}
public void details(){
    System.out.println(name+" your percentage is : "+percentage());
 
}
}
public class Tostringmethod {
    public static void main(String[] args) {
        Student s= new Student();
        s.name= "Harshit Maheshwari";
        s.rollnumber= 1802931063;
        s.sub1=99;
        s.sub2=97;
        s.sub3= 99;
        s.details();
    }
}
