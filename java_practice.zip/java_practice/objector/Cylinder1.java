package objector;
class Cylinder{
public double radius;
public double height;
public double area(){
    return 2*lidArea()+ circumference()*height;
}
public double lidArea(){
    return Math.PI*radius*radius;
}
public double circumference(){
    return 2*(Math.PI)*radius;
}
public double volume(){
    return lidArea()*height;
}

}

public class Cylinder1 {
    public static void main(String[] args) {
        Cylinder c1= new Cylinder();
        c1.radius= 7.0;
        c1.height= 10.0;
        System.out.println(c1.area()+" "+c1.lidArea()+" "+ c1.volume());
    }
}
