package objector;


class Rectangle{
    public double length;
    public double breadth;
    public double area(){
        return length*breadth;
    } 
    public double perimeter(){
        return 2*(length*breadth);
    }
    public Boolean isSquare(){
        return length==breadth;
    }
}
public class Rectangle1 {
    public static void main(String[] args) {
        Rectangle r= new Rectangle();
    r.length= 10.5;
    r.breadth=10.5;
    if(r.isSquare()){System.out.println("It is square");}
    System.out.println(r.area()+" "+r.perimeter());
}
}
