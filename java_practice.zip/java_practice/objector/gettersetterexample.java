package objector;

import java.util.*;
class Rectangle{
    private int length;
    private int breadth;

    public int getLength(){
    return length;
    }
    public void setLength(int l){
      this.length= l;
    }
    public int getBreadth(){
        return breadth;
    }
    public void setBreadth(int b){
        this.breadth= b;
    }
    public int area(){
        return length*breadth;
    }
    
}

public class gettersetterexample {
    public static void main(String[] args) {
        Rectangle r= new Rectangle();
        Scanner s=new Scanner(System.in);
        int x=r.getBreadth();
        System.out.println(x);
        int l=s.nextInt();
        int b=s.nextInt();
        r.setLength(l);
        r.setBreadth(b);
        System.out.println(r.area());
        s.close();
    }
}
