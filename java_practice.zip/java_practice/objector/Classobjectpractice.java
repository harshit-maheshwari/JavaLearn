package objector;
class circle{
    public double radius;
    public double area(){
        return Math.PI*radius*radius;
    }
    public double perimeter(){
        return 2*Math.PI*radius;
    }
    public double circumference(){
        return perimeter();
    }
}

public class Classobjectpractice {
    public static void main(String[] args) {
        
        circle c1= new circle();
        c1.radius= 5.0;
        System.out.println(c1.area()+" "+ c1.perimeter());
        circle c2= new circle();
        c2.radius= 12.0;
        System.out.println(c2.area());
    }
}
