package assignment;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


class Input{
    private int sNO;
    private String name;
    private int salary;
    private String designation;
public Input(int sNO,String name,int salary,String designation){
        this.sNO=sNO;
        this.name=name;
        this.salary=salary;
        this.designation=designation;
    }
    public String toString(){
        return "name: "+name+" salary: "+ salary+" designation: "+designation;
    }
}
public class test {

    public static void main(String[] args) throws IOException
    {
        BufferedReader br=new BufferedReader(new FileReader("./assignment/records.txt"));
        String line=null;
        int count=0;
        int maxSalary=0;
        int maxIndex=0;
        //object array
Input Employees[]= new Input[3];

while((line=br.readLine())!=null)
        {
            String temp[]= line.split("~");//line:1~Akash~12000~Accountant
            //temp[]={{1},{Akash},{12000},{Accountant}};

            Employees[count]=new Input(Integer.parseInt(temp[0]), temp[1], Integer.parseInt(temp[2]), temp[3]);

            int tempSalaryatIndex=Integer.parseInt(temp[2]);
            System.out.println(Employees[count]);

            if(tempSalaryatIndex>maxSalary){
                maxSalary=tempSalaryatIndex;
                maxIndex=count;
            }
            count++;
        }

System.out.println("Max salary Guy:"+Employees[maxIndex]+"\nout of "+count+"Guys");}}