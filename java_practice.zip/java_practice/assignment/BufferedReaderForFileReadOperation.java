package assignment;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


class Input{
    private int sNO;
    private String name;
    private int salary;
    private String designation;

    public Input(int sNO,String name,int salary,String designation){
        this.sNO=sNO;
        this.name=name;
        this.salary=salary;
        this.designation=designation;
    }
    public int getsNO() {
        return sNO;
    }
    public String getName() {
        return name;
    }
    public int getSalary() {
        return salary;
    }
    public String getDesignation() {
        return designation;
    }
    public void setDesignation(String designation) {
        this.designation = designation;
    }
    public void setSalary(int salary) {
        this.salary = salary;
    }
    public String toString() {
       
        return "\nName: "+getName()
                +"\nDesignation: "+getDesignation()
                +"\nSalary: "+getSalary();
    }

}

public class BufferedReaderForFileReadOperation {

    public static void main(String[] args) throws IOException
    {
        BufferedReader br=new BufferedReader(new FileReader("./assignment/records.txt"));
        String line=null;
        int count=0;
        while((line=br.readLine())!=null){
            count++;
        }
        br.close();

        Input Employees[]= new Input[count];
        br= new BufferedReader(new FileReader("./assignment/records.txt"));
     
        count=0;
         
        int maxSalary=0;
        int maxIndex=0;
        
        while((line=br.readLine())!=null)
        {
            String temp[]= line.split("~");
            Employees[count]=new Input(Integer.parseInt(temp[0]), temp[1], Integer.parseInt(temp[2]), temp[3]);
            int tempSalaryatIndex=Integer.parseInt(temp[2]);
            if(tempSalaryatIndex>maxSalary){
                maxSalary=tempSalaryatIndex;
                maxIndex=count;
            }
            count++;
        }

        System.out.println("Welcome to Employee Detail Portal");
        Scanner s=new Scanner(System.in);
        int index;
        while(true){
            System.out.println("\nPlease Choose options by entering Index of the option\n1. Display Details\n2. Highest Paid Employee\n3. No. of records\n4. End Session");
            index=s.nextInt();

           if(index==1){
            for(int i=0;i<count;i++){
                System.out.println(Employees[i]);
            }
           }
           else if(index==2) {System.out.println(Employees[maxIndex]);}
           else if(index==3){System.out.println(count);} 
           else if(index==4){System.out.println("Bye Bye");break;}
           else {System.out.println("Please Enter correct Character"); 
        System.out.println("");}
        }
        s.close();

        
    }

}