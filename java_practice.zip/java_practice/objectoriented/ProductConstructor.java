package objectoriented;


class Product{
    private String itemNo;
    private String name;
    private double price;
    private int quantity;
    public Product(String itemNo, String name, double price, int quantity){
        this.itemNo= itemNo;
        this.name= name;
        this.price= price;
        this.quantity= quantity;
    } 
    public Product(String itemNo, String name, double price){
        this.itemNo=itemNo;
        this.name=name;
        this.quantity=1;
    }
    public Product(String itemNo){
        this.itemNo=itemNo;
    }
    //getters
    public String getItemNo(){return this.itemNo;}
    public String getName(){return this.name;}
    public double getPrice(){return this.price;}
    public int getQuantity(){return this.quantity;}
    //setters
    public void setPrice(double price){
        this.price=price;
    }
    public void setQuantity(int quantity){
        this.quantity=quantity;
    }

}

class Customer{
    private String custID;
    private String name;
    private String address;
    private String phoneNumber;
    public Customer(String custID,String name,String address,String phoneNumber){
        this.custID= custID;
        this.name= name;
        this.address= address;
        this.phoneNumber= phoneNumber;

    }
    public Customer(String custID, String name){
        this.custID= custID;
        this.name= name;
        this.address= "NAN";
        this.phoneNumber= "NAN";

    }
    //getter 
    public String getcustID(){return this.custID ;}
    public String getName(){return this.name ;}
    public String getAddress(){return this.address ;}
    public String getPhoneNumber(){return this.phoneNumber ;}

    //setter
    public void setAddress(String address){this.address=address; }
    public void setPhoneNumber(String phoneNumber){this.phoneNumber=phoneNumber;}
    
}
public class ProductConstructor {
    public static void main(String[] args) {
        
    }
}
