package objectoriented;
class Subject{
    private String subID;
    private String name;
    private int maxMarks;
    private double marksObtained;
    public Subject(String subID,String name,int maxMarks,double marksObtained){
        this.subID=subID;
        this.name=name;
        this.marksObtained=marksObtained;
        this.maxMarks= maxMarks;
    }
    public Subject(String subID,String name,int maxMarks){
        this.subID=subID;
        this.name=name;
        this.maxMarks= maxMarks;
    }
    public Subject(String subID,int maxMarks){
        this.subID=subID;
        this.name="NAN";
        this.maxMarks= maxMarks;
    }
    //getter
    public String getSubID() {
        return subID;
    }
    public String getName() {
        return name;
    }
    public double getMarksObtained() {
        return marksObtained;
    }
    public int getMaxMarks() {
        return maxMarks;
    }
    //setter
    public void setName(String name) {
        this.name = name;
    }
    public void setMarksObtained(double marksObtained) {
        this.marksObtained = marksObtained;
    }
    public void setMaxMarks(int maxMarks) {
        this.maxMarks = maxMarks;
    }
    public boolean isQualified(){
        return marksObtained>=maxMarks/10*4;
    }
    
    public String toString() {
        return 
    "\nSubject ID: "+ subID+"\nName: "+name+"\nMarks Obtained: "+ marksObtained;
    }

}

public class ArrayOfObjects {
    public static void main(String[] args) {
        Subject subs[]= new Subject[3];
        subs[0]= new Subject("s101", "DS", 100);
        subs[1]= new Subject("s102", "DAA", 100);
        subs[2]= new Subject("s103", "OS", 100);
        for(Subject s: subs){
            System.out.println(s);
        }
    }
}
