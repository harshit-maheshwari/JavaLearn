package objectoriented;

class Cylinder{
private int radius;
private int height;

//Constructors
public Cylinder(){
    radius=1;
    height=1;
}
public Cylinder(int radius, int height){
    this.radius= radius;
    this.height= height;
}

//getter
public int getRadius(){
    return this.radius;
}
public int getHeight(){
    return this.height;
}
//setter
public void setRadius(int radius){
    this.radius= radius;
}
public void setHeight(int height){
    this.height= height;
}
public void setDimensions(int radius, int height){
    this.radius=radius;
    this.height= height;
}

//Facilitator methods/ instance methods
public double area(){
    return 2*lidArea()+ circumference()*height;
}
public double lidArea(){
    return Math.PI*radius*radius;
}
public double circumference(){
    return 2*(Math.PI)*radius;
}
public double volume(){
    return lidArea()*height;
}

public String toString(){
    return "Total area is : "+ area()
    +".\nLid area is : "+lidArea()
    +".\nVolume is : "+ volume();
}

//Query methods
public boolean isNull(){
    return (radius==0|| height==0);
}


}
public class Cylinderall {
    public static void main(String[] args) {
        Cylinder C1= new Cylinder(20, 10);
        System.out.println(C1);
        System.out.println("For dimensions "+C1.getRadius()+" "+C1.getHeight());
        C1.setDimensions(100,200);
        System.out.println("For dimensions "+C1.getRadius()+" "+C1.getHeight()+C1.isNull());

    }
}
