package objectoriented;

class Rectangle{

    private int length;
    private int breadth;
    public Rectangle(){
        length=1;
        breadth=1;
    }
    public Rectangle(int l, int b){
        length= l;
        breadth= b;
    }
    public int area(){
        return length*breadth;
    }
}


public class cunstructor {
   public static void main(String[] args) {
    Rectangle r= new Rectangle(20,10);
    Rectangle r1= new Rectangle();
    System.out.println(r1.area());
    System.out.println(r.area());
}}
