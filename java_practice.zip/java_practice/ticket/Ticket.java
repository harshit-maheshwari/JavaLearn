package ticket;
import java.util.*;
public class Ticket {
    int limit=5;
    private int ticketId,currentTicketCount=0;
    public int maxTicketCount=limit;
    private String passengerName;
    // private ();
    private String ticketArray[]= new String[maxTicketCount];

    

    public void setDetails(int ticketId,String passengerName)
    {
        this.ticketId = ticketId;
        this.passengerName = passengerName;
        ticketArray[ticketId]=passengerName;
        System.out.println(ticketId + " " + passengerName);
        currentTicketCount++;
    }

    public void getPassengerDetails(int ticketId)
    {

        if(ticketId<=ticketArray.length)
        {
            String name = ticketArray[ticketId];
            System.out.println("Passenger Details: ");
            System.out.println("Ticket id: " + ticketId);
            System.out.println("Passenger Name: " + name);
        }
        else {
            System.out.println("Passenger does not exist with this ticket id");
        }
    }
    public void setMaxTicketCount(int maxTicketCount)
    {
        this.maxTicketCount = maxTicketCount;
    }
    // public int showTicket(int ticketId){

    // }
    public int getCurrentStatus(){
        return currentTicketCount;
    }

    public int getMaxTicketCount(){
        return maxTicketCount;
    }
}