package ticket;
import java.util.*;
    public class Ticket_Assignment{
        public static void main(String[] args) {
            int limit=5;
            Scanner sc = new Scanner(System.in);
            int n,mtc;
            System.out.println("Enter the maximum ticket can be booked: ");
            mtc = sc.nextInt();

            Ticket obj = new Ticket();
            obj.setMaxTicketCount(mtc);

            do{
                System.out.println("1. Enter Details");
                System.out.println("2. Max ticket count");
                System.out.println("3. Current status");
                System.out.println("4. Ticket status");
                System.out.println("5. End");
                n = sc.nextInt();
                if(n==5)
                {
                    System.out.println("Thank you for using the software");
                    break;
                }
                else if(n>5){
                    System.out.println("Enter the valid number");
                }
               
                if(n==1)
                {
                    if(obj.getCurrentStatus() >= obj.getMaxTicketCount()||obj.getCurrentStatus()>=limit)
                    {
                        System.out.println("Cannot generate ticket, max limit exceeded");
                    }
                    else{
                        System.out.println("Enter the ticket id: ");
                        int id = sc.nextInt();

                        System.out.println("Enter the passenger name: ");
                        String name = sc.next();

                        obj.setDetails(id,name);
                        System.out.println("Passenger details saved!!");
                    }
                }
                else if(n==2)
                {
                    int maxTC = obj.getMaxTicketCount();
                    System.out.println("Maximum " + maxTC + " ticket can be booked");
                }
                else if(n==3)
                {
                    int currentStatus = obj.getCurrentStatus();
                    int max = obj.getMaxTicketCount();
                    System.out.println("Remaining ticket count is " +  (max - currentStatus));
                }
                else if(n==4)
                {
                    System.out.println("Enter the ticket ID: ");
                    int tid = sc.nextInt();
                    obj.getPassengerDetails(tid);
                }
            }
            while(n!=10);
            sc.close();
        }
        
    }
