package Method;

public class variableArgumentsArray {
    static void show(int...x){
        for(int a:x){
            System.out.println(a);
        }
    }
    static void show(int y,String...x){
        for (String a : x) {
            System.out.print(a+y+" ");
        }
    }
    public static void main(String[] args) {
        show(1,2,3,4,2);
        show(new int[]{1,4,6,7});
        show(3,"asd","we","sf","sdf","serg");
    }
}
