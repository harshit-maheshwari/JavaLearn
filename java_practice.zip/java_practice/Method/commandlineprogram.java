package Method;

import java.lang.*;
import java.util.*;
class commandlineprogram{
	public static void main(String args[]){
		
		for(String s:args){
			System.out.println(s);
		}
		System.out.println("Hi, this program is created in command line");

		}
}