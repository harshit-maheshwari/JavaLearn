package Method;

public class maxinArray {
    static int max(int A[]){
        int result=0;
        for(int i=0;i<A.length;i++){
            if(A[i]>result) result= A[i];
        }
        return result;
    }
    public static void main(String[] args) {
        int[] A= {1,2,3,4,322,123,2,21,1};
        System.out.println(max(A));

    }
}
