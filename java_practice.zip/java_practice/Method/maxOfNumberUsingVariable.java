package Method;
import java.util.*;
public class maxOfNumberUsingVariable {
    static int max(int...A){
        if(A.length==0) return Integer.MIN_VALUE;
        int m= A[0];
        for(int i=1;i<A.length;i++){
            if(A[i]>A[0]) m=A[i];
        }
        return m;
    }
    
    public static void main(String[] args) {
        int x;
        Scanner s= new Scanner(System.in);
        int y;
        x= s.nextInt();
        for(int i=0;i<x;i++){
            y=s.nextInt();
        }
        int z=max(1,2,3,5);
        System.out.println(z);
      
        
    }
}
