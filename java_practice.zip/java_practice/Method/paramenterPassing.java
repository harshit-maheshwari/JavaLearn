package Method;

public class paramenterPassing {
    int add(int x, int y){
        x=x+y;
        return x;
    }
    void welcome(String n){
        System.out.println("Welcome "+n);
    }
    public static void main(String[] args) {
        int x=3, y=34;
        String name= "Harshit";
        paramenterPassing m= new paramenterPassing();
        System.out.println(m.add(x,y));
        m.welcome(name);
    }
}
