package Method;

public class methodOverloading {
    static int max(int x, int y){
        System.out.println("int");
        return x>y? x:y;
    }
    static float max(float x, float y){
        System.out.println(" float");
        return x>y?x:y;
    }
    public static void main(String[] args) {
        System.out.println(max(332f,2345f));

    }
}
