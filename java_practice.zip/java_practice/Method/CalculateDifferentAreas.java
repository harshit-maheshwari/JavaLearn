package Method;

public class CalculateDifferentAreas {
    static int area(int a, int b){
        return a*b;
    }
    static double area(int a){
        return Math.PI*a*a;
    }
    static double area(int a, int b, int c){
        return 1/2*((a+b)*c);
    }
    public static void main(String[] args) {
        int a=23,b=345;
        System.out.print(area(a));
        System.out.print(" "+ area(a,b));
        System.out.print(" "+ area(a,b,10));

        

    }
}
