package Method;
import java.util.*;
public class FindGCD {
    static int CheckGCD(int num1, int num2){
        int result=1;
        while(num1!=num2){
            if(num1>num2) num1-=num2;
            else num2-=num1;
        }
        if(num1==num2) result=num2;
        return result;
    }
    public static void main(String[] args) {
       Scanner s= new Scanner(System.in);
       System.out.println("Enter number");
       int num1= s.nextInt();
       int num2= s.nextInt();
       System.out.println(CheckGCD(num1,num2));
       s.close();

    }
}
