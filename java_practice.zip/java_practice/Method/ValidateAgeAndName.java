package Method;

public class ValidateAgeAndName {
    static Boolean Validate(String name){
        return name.matches("[a-zA-z\\s]*");
    }
    static Boolean Validate(int age){
        return (age>18&& age<28);
       
    }
    public static void main(String[] args) {
        int age=21;
        String name="Harshit Maheshwari";
        if(Validate(age)&&Validate(name)){
            System.out.println("Yeh Yeh");
        }
        else System.out.println("nAHHHHHHHH");
    }
}

