package Method;

public class reverseintorarray {
    static int reverse(int A){
        int x=A,result=0;
        while(x>0){
            result= result*10+A%10;
            A/=10;
        }
        return result;
    }
    static int[] reverse(int A[]){
        
        int[] B= new int[A.length];
        for(int i=0;i<A.length;i++){
            B[A.length-1-i]=A[i];
            }
           
        return B;}

        
    public static void main(String[] args) {
        int x=12345;
        int y[]= {1,2,3,4,5,6};
        int B[]= reverse(y);
        System.out.println(x+"\n");
        for(int a:B){
            System.out.print(" "+ a);
        }
    }
}
