package Method;
import java.util.*;
public class Findprime {
    static Boolean CheckPrime(int num){
        Boolean b= false;
        if(num%2==0 || num%3==0 ||num%5==0||num%7==0||num%11==0||num%13==0||num%17==0||num%19==0){
            return b;
        }
        else{
            for(int i=23;i<(int)Math.sqrt(num);i++){
                if(num%i==0){
                    return b;
                }
            }

        }
        b=true;

        return b;
    }

    public static void main(String[] args) {
        Scanner s= new Scanner(System.in);
        System.out.println("Enter the number to check prime");
        int num=s.nextInt();
        System.out.println(CheckPrime(num));
        s.close();
    }
}
