package Method;
public class method1 {
    int max(int x,int y){
        if(x>y) return x;
        else return y;
        }
    public static void main(String[] args) {
        method1 m=new method1();
        System.out.print(m.max(2,4));
    }
   
}
