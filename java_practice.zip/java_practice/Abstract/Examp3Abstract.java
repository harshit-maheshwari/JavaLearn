package Abstract;
abstract class Shape{
    abstract double area();
    abstract double perimeter();

}
class Circle extends Shape{
    private double radius;
    public Circle(double radius){
        this.radius= radius;
    }
    public double area(){
        return Math.PI*radius*radius;
    }
    public double perimeter(){
        return 2*Math.PI*radius;
    }
}
class Rectangle extends Shape{
    private double length;
    private double breadth;
    Rectangle(double length, double breadth){
        this.length= length;
        this.breadth= breadth;
    }
    public double area(){
        return length*breadth;
    }
    public double area(double length,double breadth){
        return length*breadth;
    }

    public double perimeter(){
        return 2*(length*breadth);
    }

}


public class Examp3Abstract {
    public static void main(String[] args) {
        Circle c= new Circle(20);
        Rectangle r = new Rectangle(10,20);
        System.out.println("Circle: "+ c.area()+" "+c.perimeter());
        System.out.println("Rectangle: "+ r.area()+" "+ r.perimeter());
}
}