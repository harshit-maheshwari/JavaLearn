package Abstract;
//for standardise the class that it must have atleast these things
abstract class Hospital{
    abstract void emergency();
    abstract void appointment();
    abstract void admit();
    abstract void billing();
    abstract void checkup();
}
class MyHospital extends Hospital{

    public void emergency(){
        System.out.println("Emergency Ward");
    }
    public void appointment(){
        System.out.println("Appointment Scheduled");
    }
    public void admit(){
        System.out.println("Admitted");
    }
    public void billing(){
        System.out.println("Billed");
    }
    public void checkup(){
        System.out.println("Checkup done");
    }

}
public class RealLifeExampleOfAbstract {
    public static void main(String[] args) {
        Hospital h= new MyHospital();
        h.admit();
    }
}
