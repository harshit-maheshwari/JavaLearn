package Abstract;
abstract class KFC{
    KFC(){
        System.out.println("Finger Licking good");
    }
    void makeItem(){
        System.out.println("Sexy Burgers");
    }
    abstract void billing();
    abstract void offer();
}
class MyKFC extends KFC{
    MyKFC(){
        System.out.println("This is my KFC");
    }
    void billing(){
        System.out.println("BIlling chilling");
    }
    void offer(){
        System.out.println("lofer no offer");
    }
    void festiveOffer(){
        System.out.println(" by me not KFC");
    }
}

public class Examp2Abstract {
    public static void main(String[] args) {
        MyKFC kasganjKFC= new MyKFC();
        kasganjKFC.billing();
        kasganjKFC.offer();
        kasganjKFC.festiveOffer();


    }
}
